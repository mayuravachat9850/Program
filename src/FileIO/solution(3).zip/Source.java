public class Source {

   /*
    * TODO 4: The BookNotFoundException should be specified in the method signature of the getBook() method.
    */
   public static Book getBook(Book[] books, String bookName) throws BookNotFoundException {
      boolean found = false;
      Book book = null;
      for (int i = 0; i < books.length; i++) {
         if (books[i].getName().equals(bookName)) {
            book = books[i];
            found = true;
            break;
         }
      }

      /*
       * TODO 3: When a book is not found, then you should throw
       * BookNotFoundException. The exception message should be: "Book <bookName>
       * not found", where <bookName> is actual name of the book
       */
      if (!found) {
         throw new BookNotFoundException("Book " + bookName + " not found");
      }

      return book;
   }

   public static void main(String[] args) {
      Book[] books = getBooks();
      try {
         System.out.println(getBook(books, "Arion and the Dolphin"));
         // uncomment below line and comment above line for testing sample test case 2
         System.out.println(getBook(books, "Broken Wings"));
      } catch (BookNotFoundException e) {
         System.out.println(e.getMessage());
      }
   }

   public static Book[] getBooks() {
      Book[] books = new Book[4];
      Book b1 = new Book("An Autobiography", "Jawaharlal Nehru");
      Book b2 = new Book("An idealist View of Life", "Dr.S. Radhakrishnan");
      Book b3 = new Book("Arion and the Dolphin", "Vikram Seth");
      Book b4 = new Book("Arthashastra", "Kautilya");

      books[0] = b1;
      books[1] = b2;
      books[2] = b3;
      books[3] = b4;
      return books;
   }
}
