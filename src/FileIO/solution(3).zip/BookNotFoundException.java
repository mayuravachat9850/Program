/*
 * TODO 1: Modify this class so that it can inherit exception properties.
 */
public class BookNotFoundException extends Exception {
   public BookNotFoundException(String message) {
      /*
       * TODO 2: Call the superclass constructor from the constructor of BookNotFoundException and pass the exception message as an argument.
       */
      super(message);
   }
}