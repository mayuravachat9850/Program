import java.util.*;

public class Source {
   public static Set<String> getCountries(Participant[] participants) {
      /*
       * TODO: Return the set of unique countries from where the participants
       * have come. (Hint. Use LinkedHashSet to maintain order)
       */
      Set<String> countries = new LinkedHashSet<>();
      for (int i = 0; i < participants.length; i++) {
         countries.add(participants[i].getCountry());
      }
      return countries;
   }

   public static void main(String[] args) {
      Participant[] participants = getParticipants1();
      //uncomment below line and comment above line for testing sample test case 2
//      Participant[] participants = getParticipants2();
      Set<String> set = getCountries(participants);
      for (String entry : set) {
         System.out.println(entry);
      }
   }

   public static Participant[] getParticipants1() {
      Participant[] participants = new Participant[5];
      Participant p1 = new Participant("John Doe", "Australia");
      Participant p2 = new Participant("David Hope", "Australia");
      Participant p3 = new Participant("Rahul Mandal", "India");
      Participant p4 = new Participant("Rachel Warner", "USA");
      Participant p5 = new Participant("Richard Harris", "USA");
      participants[0] = p1;
      participants[1] = p2;
      participants[2] = p3;
      participants[3] = p4;
      participants[4] = p5;
      return participants;
   }

   public static Participant[] getParticipants2() {
      Participant[] participants = new Participant[3];
      Participant p1 = new Participant("Kelly Adams", "Australia");
      Participant p2 = new Participant("Angela Morris", "USA");
      Participant p3 = new Participant("Rachel Warner", "UK");
      participants[0] = p1;
      participants[1] = p2;
      participants[2] = p3;
      return participants;
   }
}
