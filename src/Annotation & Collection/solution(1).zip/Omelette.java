public class Omelette extends Food {
   public Omelette() {
      this.prepareFood();
   }
   @Override
   public void prepareFood() {
      System.out.println("Preparing omelette!");
   }
}
