public class Source {
   public static void main(String[] args) {
      String ingredient;
      
      if(args != null && args.length > 0) {
         ingredient = args[0];
      } else {
         ingredient = "rice";
         // uncomment below line and comment above line for testing sample test case 2
//         ingredient = "apple";
      }
      
      Maid.cookFood(ingredient);
   }
}
