public abstract class Food {
   public abstract void prepareFood();
}
