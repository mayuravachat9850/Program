public class Maid {
   
   /**
    * TODO1: Create a method cookFood that will take the ingredient of the type String as the input argument.
    * The returned object will be based on the ingredient supplied. 
    * if the 'rice' ingredient is supplied, then you should return object of the Biryani.java class
    * or if the 'wheat' ingredient is supplied, then you should return object of Bread.java class
    * or if the 'egg' ingredient is supplied, then you should return object of Omelette.java class
    * if the ingredient is not rice, wheat or egg, then return null.
    */
   public static Food cookFood(String ingredient) {
      if(ingredient.equals("rice")) {
         return new Biryani();
      }
      else if(ingredient.equals("wheat")) {
         return new Bread();
      }
      else if(ingredient.equals("egg")) {
         return new Omelette();
      }
      
      return null;
   }
}
