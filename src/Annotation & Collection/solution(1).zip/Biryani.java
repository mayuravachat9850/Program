public class Biryani extends Food {
   public Biryani() {
      this.prepareFood();
   }
   @Override
   public void prepareFood() {
      System.out.println("Preparing biryani!");
   }
}
