public class Order {
   private String fruit;
   private int quantity;
   public Order(String product, int quantity) {
      this.fruit = product;
      this.quantity = quantity;
   }

   public String getFruit() {
      return fruit;
   }

   public int getQuantity() {
      return quantity;
   }
   
   @Override
   public String toString() {
      return this.fruit + ": " + this.quantity;
   }
}
