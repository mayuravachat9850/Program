import java.util.*;

public class Source {
   public static List<Order> getOrdersByDescendingOrderOfQuantity(Order[] orderArray) {
      List<Order> orders = new ArrayList<>();
      for (int i = 0; i < orderArray.length; i++) {
         orders.add(orderArray[i]);
      }

      orders.sort(getComparatorForDescendingOrderOfQuantity());
      
      return orders;
   }
   
   public static Comparator<Order> getComparatorForDescendingOrderOfQuantity(){
      /*
       * TODO: Write your code below. This method should return a comparator
       * which sorts the order list in the descending order of quantity of fruit
       */
      return new Comparator<Order>() {
         @Override
         public int compare(Order o1, Order o2) {
            return o2.getQuantity() - o1.getQuantity();
         }
      };
   }

   public static void main(String[] args) {
      Order[] orderArray = getProducts1();
      //uncomment below line and comment above line for testing sample test case 2
//      Order[] orderArray = getProducts2();
      List<Order> topScorers = getOrdersByDescendingOrderOfQuantity(orderArray);
      System.out.println(topScorers);
   }

   public static Order[] getProducts1() {
      Order[] orderArray = new Order[5];
      Order o1 = new Order("Apple", 150);
      Order o2 = new Order("Orange", 130);
      Order o3 = new Order("Banana", 210);
      Order o4 = new Order("Kiwi", 175);
      Order o5 = new Order("Watermelon", 240);
      orderArray[0] = o1;
      orderArray[1] = o2;
      orderArray[2] = o3;
      orderArray[3] = o4;
      orderArray[4] = o5;
      return orderArray;
   }

   public static Order[] getProducts2() {
      Order[] orderArray = new Order[3];
      Order o1 = new Order("Apple", 150);
      Order o2 = new Order("Orange", 170);
      Order o3 = new Order("Banana", 180);
      orderArray[0] = o1;
      orderArray[1] = o2;
      orderArray[2] = o3;
      return orderArray;
   }
}
