/*TODO: Remove the setDetail() method and mark this interface 
 *with @FunctionalInterface annotation
 */
@FunctionalInterface
public interface TVOrder {
 abstract void printOrderDetails(int numberOfTVs, int pricePerTV);
}

