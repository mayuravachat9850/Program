public class Source {
   public static void main(String[] args) {
      int numberOfTVs, pricePerTV;

      if (args != null && args.length == 2) {
         numberOfTVs = Integer.parseInt(args[0]);
         pricePerTV = Integer.parseInt(args[1]);
      } else {
         numberOfTVs = 3; pricePerTV = 200;
         // uncomment below line and comment above line for testing sample test case 2
//         numberOfTVs = 2; pricePerTV = 110;
      }

      TVOrder order = getTvOrder();
      order.printOrderDetails(numberOfTVs, pricePerTV);
   }

   public static TVOrder getTvOrder() {
      TVOrder order = new TVOrder() {
         @Override
         public void printOrderDetails(int numberOfTVs, int pricePerTV) {
            System.out.println(numberOfTVs * pricePerTV);
         }
      };

      return order;
   }
}
