public class Follower {
   private String name;

   public Follower(String name) {
      this.name = name;
   }

   /*
    * TODO 1: Create a method newPost, which takes the two input arguments 
    * celebrityName of type String and post of type String. 
    * This method should not return anything. 
    * This method should print: Hi <followerName>! <celebrityName> has posted a <post>
    */

   public void newPost(String celebrityName, String post) {
      System.out.println("Hi " + name + "! " + celebrityName + " has posted a " + post);
   }
}
