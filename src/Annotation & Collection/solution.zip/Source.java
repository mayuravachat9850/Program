public class Source {
   public static void main(String[] args) {
      if(args != null && args.length == 3) {
         testApp(args[0], args[1], args[2]);
      } else {
         testApp("Amitabh Bacchan", "Rahul,Nikita,Manoj", "picture of his childhood!");
         // uncomment below code and comment above code to test sample test case 2
//      testApp("Katrina Kaif", "Ajay,Bharti,Umesh,Kamesh,Richa", "dance video!");
      }
      
   }
   
   public static void testApp(String celebrityName, String followerNamesString, String post) {
      Celebrity celebrity = new Celebrity(celebrityName);
      if(followerNamesString != null && !followerNamesString.isEmpty()) {
         String[] followerNames = followerNamesString.split(",");
         for(String followerName: followerNames) {
            Follower follower = new Follower(followerName);
            celebrity.addFollower(follower);
         }
      }
      
      celebrity.addPost(post);
   }
}
