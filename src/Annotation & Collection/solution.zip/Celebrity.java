public class Celebrity {
   String celebrityName;
   
   private Follower[] followers = new Follower[100]; // Max 100 followers allowed
   
   // current followers count. If count is -1 means that currently no follower exists.
   int totalFollowers = -1;
   
   public Celebrity(String name) {
      this.celebrityName = name;
   }
   
   // method to add a new follower to this celebrity
   public void addFollower(Follower follower) {
      followers[++totalFollowers] = follower;
   }
   
   public void addPost(String post) {
      if(totalFollowers != -1) {
         for(int i=0; i<=totalFollowers;i++) {
            /*
             * TODO 2: invoke method created in TODO 1 on each of the follower 
             * objects present in the followers array
             */
            followers[i].newPost(this.celebrityName, post);
         }
      }
   }
}
