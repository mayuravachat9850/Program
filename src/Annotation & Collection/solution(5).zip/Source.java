import java.util.*;
import java.io.*;

public class Source {
	/*
	 * TODO 1: Complete the following method printMap(map)
	 * It should print the key-value(s) in the following format
	 * <key1>
	 * <tab>1. <value1>
	 * <tab>2. <value2>
	 * ...
	 * <key2>
	 * <tab>1. <value1>
	 * <tab>1. <value1>
	 * ...
	 */
   private static void printMap (Map<String, List<String>> map) {
       for (Map.Entry<String, List<String>> entry : map.entrySet()) {
           System.out.println(entry.getKey());
           List<String> list = entry.getValue();
           for (int i=0; i<list.size(); i++) {
               System.out.println("\t" + (i+1) + ". " + list.get(i));
           }
       }
   }

   //Don't make any change to the following code, or your code may not run
   public static void main (String[] args) throws Exception {
       Map<String, List<String>> map = new LinkedHashMap<>();
       int n = Integer.parseInt(br.readLine());
       while (n-- > 0) {
    	   String key = br.readLine();
    	   List<String> value = Arrays.asList(br.readLine().split(" "));
           map.put(key, value);
       }
       printMap(map);
   }
   
   static BufferedReader br = null;

   private static void setBr() {
   	try {
   		//br = new BufferedReader(new InputStreamReader(System.in));
   		br = new BufferedReader(new FileReader("/code/workspace/sample_input.txt"));
   	} catch (Exception e) {
   		br = null;
   	}
   }

   static {
   	setBr();
   }
}

